
'use strict';
const HUB    = 'http://127.0.0.1:8766';
const LF_HDR = 'LF1.B.H.1.5.ING';
const PRESETS = ['ia','code','security','network','devops','system',
                 'bibliography','neuromorphic','research','web','exploit','collab'];

const params      = new URLSearchParams(location.search);
const sourceTabId = parseInt(params.get('tabId'));
let _pending = [], _tags = new Set(), tabsLoaded = false, histTimer = null;

// ── Navigation tabs ──────────────────────────────────────────────────────────
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById('tab-' + btn.dataset.tab).classList.add('active');
    if (btn.dataset.tab === 'tabs' && !tabsLoaded) loadTabs();
  });
});

// ── Helpers ──────────────────────────────────────────────────────────────────
function addItem(listEl, url, title) {
  const d = document.createElement('div');
  d.className = 'item';
  d.innerHTML = `<input type="checkbox" data-url="${esc(url)}" data-title="${esc(title)}">
    <div style="flex:1;overflow:hidden;min-width:0">
      <div class="ititle">${esc(title)}</div>
      <div class="iurl">${esc(url)}</div>
    </div>`;
  // Clic sur toute la ligne coche la case
  d.addEventListener('click', e => {
    if (e.target.tagName !== 'INPUT') d.querySelector('input').click();
  });
  listEl.appendChild(d);
  return d;
}

function esc(s) { return (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;'); }

function syncCount(listId, countId, btnId) {
  const all     = document.querySelectorAll(`#${listId} input`);
  const checked = document.querySelectorAll(`#${listId} input:checked`);
  document.getElementById(countId).textContent = `${checked.length}/${all.length}`;
  document.getElementById(btnId).disabled = checked.length === 0;
}

function bindList(listId, countId, btnId, sendId, copyId) {
  document.getElementById(listId).addEventListener('change', () => syncCount(listId, countId, btnId));
  document.getElementById(sendId).addEventListener('click',  () => onSendClick(getChecked(listId)));
  document.getElementById(copyId).addEventListener('click',  () => {
    navigator.clipboard.writeText(JSON.stringify(getChecked(listId), null, 2));
  });
  document.getElementById(`${listId.replace('-list','')}-all`).addEventListener('click', () => {
    document.querySelectorAll(`#${listId} input`).forEach(cb => cb.checked = true);
    syncCount(listId, countId, btnId);
  });
  document.getElementById(`${listId.replace('-list','')}-none`).addEventListener('click', () => {
    document.querySelectorAll(`#${listId} input`).forEach(cb => cb.checked = false);
    syncCount(listId, countId, btnId);
  });
}

function getChecked(listId) {
  return [...document.querySelectorAll(`#${listId} input:checked`)]
    .map(cb => ({ url: cb.dataset.url, title: cb.dataset.title }));
}

// ── Tag Panel ────────────────────────────────────────────────────────────────
// Créer les chips preset une seule fois
const chipsDiv = document.getElementById('tag-chips');
PRESETS.forEach(t => {
  const c = document.createElement('span');
  c.className = 'tag-chip'; c.textContent = t; c.dataset.tag = t;
  c.addEventListener('click', () => {
    c.classList.toggle('on');
    if (c.classList.contains('on')) _tags.add(t); else _tags.delete(t);
    renderTags();
  });
  chipsDiv.appendChild(c);
});

document.getElementById('tag-custom').addEventListener('keydown', e => {
  if (e.key === 'Enter' && e.target.value.trim()) {
    _tags.add(e.target.value.trim()); e.target.value = ''; renderTags();
  }
});

document.getElementById('tag-cancel').addEventListener('click', closeTagPanel);
document.getElementById('tag-ok').addEventListener('click', sendWithTags);

function renderTags() {
  document.getElementById('tag-active').textContent =
    _tags.size ? '🏷️ ' + [..._tags].join(' · ') : '';
}

function openTagPanel(items, withText=false) {
  if (!items.length) return;
  _pending = items; _tags.clear();
  document.querySelectorAll('.tag-chip').forEach(c => c.classList.remove('on'));
  document.getElementById('tag-custom').value = '';
  document.getElementById('tag-note').value   = '';
  document.getElementById('tag-domain').value = '';
  document.getElementById('tag-active').textContent = '';
  document.getElementById('tag-result').textContent = '';
  document.getElementById('tag-panel').style.display = 'block';
  document.body.style.paddingBottom = '120px';
}

function closeTagPanel() {
  document.getElementById('tag-panel').style.display = 'none';
  document.body.style.paddingBottom = '0';
}

async function sendWithTags() {
  const domain = document.getElementById('tag-domain').value || 'general';
  const note   = document.getElementById('tag-note').value;
  const tags   = [..._tags];
  const res    = document.getElementById('tag-result');
  res.textContent = `Envoi ${_pending.length} URLs...`; res.style.color = '#888';

  let sent = 0;
  for (const item of _pending) {
    try {
      await fetch(`${HUB}/ingest/url`, {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({ header: LF_HDR, body: {
          url: item.url, title: item.title,
          source: 'linkgopher', tags, domain, notes: note,
          keywords: tags.join(', '), priority: 3
        }}),
        signal: AbortSignal.timeout(3000)
      });
      sent++;
    } catch(e) {}
  }

  // Notifier hub → biblio worker
  try {
    await fetch(`${HUB}/mcp`, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ jsonrpc:'2.0',id:1,method:'tools/call',
        params:{ name:'hub', arguments:{ action:'notify',
          message:`[BROWSER][INGEST] ${sent} URLs · tags:[${tags}] · domain:${domain}`
        }}
      })
    });
  } catch(e) {}

  res.textContent = `✓ ${sent}/${_pending.length} envoyées — tags:[${tags.join(', ')||'aucun'}] domain:${domain}`;
  res.style.color = '#00ff88';
  setTimeout(closeTagPanel, 3000);
}

// ── TAB Page courante ────────────────────────────────────────────────────────
bindList('page-list','page-count','page-send','page-send','page-copy');

(async () => {
  const list = document.getElementById('page-list');
  const st   = document.getElementById('page-status');
  try {
    const r = await chrome.runtime.sendMessage({ action:'extractLinks', tabId: sourceTabId });
    if (!r || r.error) throw new Error(r?.error || 'no response');
    const links = (r.links||[]).filter(l => l.startsWith('http'));
    if (!links.length) { st.textContent='Aucun lien'; return; }
    links.forEach(url => addItem(list, url, url));
    st.textContent = `${links.length} liens`; st.className = 'lf-status ok';
  } catch(e) {
    st.textContent = 'Erreur: '+e.message; st.className = 'lf-status warn';
  }
})();

// ── TAB Onglets ──────────────────────────────────────────────────────────────
bindList('tabs-list','tabs-count','tabs-send','tabs-send','tabs-copy');

async function loadTabs() {
  tabsLoaded = true;
  const list = document.getElementById('tabs-list');
  const st   = document.getElementById('tabs-status');
  const r    = await chrome.runtime.sendMessage({ action:'getTabs' });
  (r.tabs||[]).forEach(t => addItem(list, t.url, t.title||t.url));
  st.textContent = `${(r.tabs||[]).length} onglets`; st.className = 'lf-status ok';
}

// ── TAB Historique ───────────────────────────────────────────────────────────
bindList('hist-list','hist-count','hist-send','hist-send','hist-copy');

document.getElementById('hist-search').addEventListener('input', e => {
  clearTimeout(histTimer);
  histTimer = setTimeout(() => loadHistory(e.target.value), 300);
});

// Auto-charger à l'ouverture de l'onglet historique
document.querySelector('[data-tab="history"]').addEventListener('click', () => {
  const list = document.getElementById('hist-list');
  if (!list.children.length) loadHistory(''); // chargement initial si vide
});

async function loadHistory(query) {
  const list = document.getElementById('hist-list');
  const st   = document.getElementById('hist-status');
  list.innerHTML = '';
  st.textContent = 'Recherche...'; st.className = 'lf-status';
  try {
    const r = await chrome.runtime.sendMessage({ action:'getHistory', query, maxResults:300 });
    const items = r.history || [];
    if (!items.length) {
      st.textContent = query
        ? 'Aucun résultat pour "' + query + '"'
        : 'Historique vide ou non accessible (navigation privée ?)';
      st.className = 'lf-status warn';
      return;
    }
    items.forEach(h => {
      const date = new Date(h.lastVisit).toLocaleDateString('fr-FR');
      const item = addItem(list, h.url, h.title || h.url);
      // Ajouter la date comme info supplémentaire
      const dateEl = document.createElement('span');
      dateEl.style.cssText = 'color:#444;font-size:10px;flex-shrink:0;white-space:nowrap';
      dateEl.textContent = date + (h.visitCount > 1 ? ` (${h.visitCount}x)` : '');
      item.appendChild(dateEl);
    });
    st.textContent = `${items.length} entrées (90 derniers jours)`;
    st.className = 'lf-status ok';
    syncCount('hist-list','hist-count','hist-send');
  } catch(e) {
    st.textContent = 'Erreur: ' + e.message; st.className = 'lf-status warn';
  }
}


// ── TAB Texte page ───────────────────────────────────────────────────────────
let _pageTextData = null;

document.querySelector('[data-tab="text"]').addEventListener('click', async () => {
  if (_pageTextData) return; // déjà chargé
  const st = document.getElementById('text-status');
  st.textContent = 'Extraction...'; st.className = 'lf-status';
  try {
    const r = await chrome.runtime.sendMessage({ action:'extractText', tabId:sourceTabId });
    if (!r || r.error) throw new Error(r?.error || 'no response');
    _pageTextData = r.data;
    document.getElementById('text-preview').textContent =
      _pageTextData.selected
        ? `[Sélection détectée]\n${_pageTextData.selected}\n\n[Texte complet]\n${_pageTextData.text}`
        : _pageTextData.text;
    st.textContent = `${_pageTextData.text.length} chars — "${_pageTextData.title.substring(0,40)}"`;
    st.className = 'lf-status ok';
  } catch(e) {
    st.textContent = 'Erreur: '+e.message; st.className = 'lf-status warn';
  }
});

document.getElementById('text-send-sel').addEventListener('click', async () => {
  if (!_pageTextData) return;
  const text = _pageTextData.selected || _pageTextData.text.substring(0,2000);
  openTagPanel([{ url: _pageTextData.url, title: _pageTextData.title, text }], true);
});

document.getElementById('text-send-all').addEventListener('click', async () => {
  if (!_pageTextData) return;
  openTagPanel([{ url: _pageTextData.url, title: _pageTextData.title, text: _pageTextData.text }], true);
});

document.getElementById('text-copy').addEventListener('click', () => {
  if (_pageTextData) navigator.clipboard.writeText(_pageTextData.selected || _pageTextData.text);
});


// ── Qualification LLM avant ingestion ────────────────────────────────────────
async function qualifyAndSend(items) {
  const st = document.getElementById('qualify-status') || createQualifyUI();
  st.style.display = 'block';

  const total = items.length;
  let qualified = 0;

  setQualifyStatus(`Ouverture et extraction de ${total} URLs...`, '#888');

  // 1. Extraction texte via background
  let extracted = [];
  try {
    const r = await chrome.runtime.sendMessage({ action:'qualifyUrls', items });
    extracted = r.results || [];
  } catch(e) {
    setQualifyStatus('Erreur extraction: ' + e.message, '#ffaa00');
    return;
  }

  // 2. Envoi au hub pour qualification LLM + ingestion
  setQualifyStatus(`Qualification LLM de ${extracted.length} docs...`, '#888');

  for (const doc of extracted) {
    if (!doc.ok) {
      setQualifyStatus(`⚠ ${doc.url.substring(0,50)} — ${doc.error}`, '#ffaa00');
      continue;
    }

    try {
      // Le hub va qualifier via LLM (tags, domaine, résumé) puis insérer en biblio_raw
      await fetch(`${HUB}/ingest/qualify`, {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({
          header: LF_HDR,
          body: {
            url:      doc.url,
            title:    doc.title || doc.h1,
            text:     doc.text,
            meta_desc: doc.desc,
            keywords: doc.keywords,
            headings: [doc.h1, doc.h2s].filter(Boolean).join(' | '),
            lang:     doc.lang,
            source:   'linkgopher_qualify'
          }
        }),
        signal: AbortSignal.timeout(30000)
      });
      qualified++;
      setQualifyStatus(`✓ ${qualified}/${total} qualifiés...`, '#888');
    } catch(e) {
      // Fallback : ingestion directe sans qualification LLM
      await fetch(`${HUB}/ingest/url`, {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ header:LF_HDR, body:{url:doc.url, title:doc.title, text:doc.text, source:'linkgopher'} }),
        signal: AbortSignal.timeout(5000)
      }).catch(()=>{});
    }
  }

  setQualifyStatus(`✓ ${qualified}/${total} qualifiés et ingérés`, '#00ff88');

  // Notifier hub
  try {
    await fetch(`${HUB}/mcp`, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ jsonrpc:'2.0',id:1,method:'tools/call',
        params:{ name:'hub', arguments:{ action:'notify',
          message:`[BROWSER][QUALIFY] ${qualified}/${total} docs qualifiés par LLM et ingérés`
        }}
      })
    });
  } catch(e) {}
}

function createQualifyUI() {
  // Ajouter barre de statut qualification en haut de page
  const bar = document.createElement('div');
  bar.id = 'qualify-status-bar';
  bar.style.cssText = 'position:fixed;top:0;left:0;right:0;padding:8px 16px;font-family:monospace;font-size:12px;z-index:200;display:none;text-align:center';
  document.body.appendChild(bar);
  return bar;
}

function setQualifyStatus(msg, color='#888') {
  let bar = document.getElementById('qualify-status-bar');
  if (!bar) bar = createQualifyUI();
  bar.style.display = 'block';
  bar.style.background = '#161b22';
  bar.style.borderBottom = `2px solid ${color}`;
  bar.style.color = color;
  bar.textContent = msg;
  if (color === '#00ff88') setTimeout(() => { bar.style.display='none'; }, 5000);
}


// Modifier les boutons send pour offrir le choix
function onSendClick(items) {
  if (!items.length) return;

  // Créer dialog de choix
  const overlay = document.createElement('div');
  overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:150;display:flex;align-items:center;justify-content:center';

  overlay.innerHTML = `
    <div style="background:#161b22;border:1px solid #00d4ff;border-radius:8px;padding:24px;max-width:420px;font-family:monospace;text-align:center">
      <div style="color:#00d4ff;font-weight:bold;font-size:15px;margin-bottom:12px">
        ⚡ ${items.length} URL${items.length>1?'s':''} sélectionnée${items.length>1?'s':''}
      </div>
      <div style="color:#8b949e;font-size:12px;margin-bottom:20px;line-height:1.6">
        Comment veux-tu les ingérer ?
      </div>
      <div style="display:flex;flex-direction:column;gap:10px">
        <button id="choice-qualify" style="background:#00d4ff;color:#000;border:none;padding:10px;border-radius:4px;cursor:pointer;font-family:monospace;font-weight:bold">
          🔬 Qualifier par LLM<br>
          <span style="font-weight:normal;font-size:11px">Ouvre chaque doc, extrait le texte, LLM assigne tags+domaine+résumé</span>
        </button>
        <button id="choice-tag" style="background:#222;color:#ccc;border:1px solid #444;padding:10px;border-radius:4px;cursor:pointer;font-family:monospace">
          🏷️ Tags manuels rapides<br>
          <span style="font-size:11px;color:#666">Choisir tags globaux maintenant, ingestion immédiate</span>
        </button>
        <button id="choice-cancel" style="background:none;color:#555;border:none;cursor:pointer;font-size:12px">Annuler</button>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);
  document.getElementById('choice-qualify').addEventListener('click', () => {
    overlay.remove();
    qualifyAndSend(items);
  });
  document.getElementById('choice-tag').addEventListener('click', () => {
    overlay.remove();
    openTagPanel(items);
  });
  document.getElementById('choice-cancel').addEventListener('click', () => overlay.remove());
}
