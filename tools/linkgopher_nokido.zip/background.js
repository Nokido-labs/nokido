
// background.js v4.0
const HUB    = 'http://127.0.0.1:8766';
const LF_HDR = 'LF1.B.H.1.5.ING';

// ── Menus contextuels ────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(() => {
  // Menu sur texte sélectionné
  chrome.contextMenus.create({
    id: 'lf-send-text',
    title: '⚡ Envoyer le texte à LaForge',
    contexts: ['selection']
  });
  // Menu sur lien
  chrome.contextMenus.create({
    id: 'lf-send-link',
    title: '⚡ Envoyer ce lien à LaForge',
    contexts: ['link']
  });
  // Menu sur page entière
  chrome.contextMenus.create({
    id: 'lf-send-page',
    title: '⚡ Envoyer cette page à LaForge',
    contexts: ['page']
  });
  // Séparateur + ouvrir Link Gopher
  chrome.contextMenus.create({ id: 'lf-sep', type: 'separator', contexts: ['page','selection','link'] });
  chrome.contextMenus.create({
    id: 'lf-open',
    title: '🔗 Ouvrir Link Gopher',
    contexts: ['page','selection','link']
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === 'lf-send-text') {
    await hubIngest({
      header: LF_HDR,
      body: {
        url:    tab.url,
        title:  tab.title,
        text:   info.selectionText,
        source: 'contextmenu_selection',
        type:   'text_selection'
      }
    });
    notify(tab.id, `✓ Texte envoyé à LaForge (${info.selectionText.length} chars)`);
  }
  if (info.menuItemId === 'lf-send-link') {
    await hubIngest({
      header: LF_HDR,
      body: { url: info.linkUrl, title: info.linkUrl, source: 'contextmenu_link' }
    });
    notify(tab.id, `✓ Lien envoyé : ${info.linkUrl.substring(0,60)}...`);
  }
  if (info.menuItemId === 'lf-send-page') {
    // Extraire texte + meta de la page
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => ({
        url:   location.href,
        title: document.title,
        text:  document.body.innerText.substring(0, 8000),
        meta:  document.querySelector('meta[name="description"]')?.content || ''
      })
    });
    const data = results?.[0]?.result;
    if (data) {
      await hubIngest({ header: LF_HDR, body: { ...data, source: 'contextmenu_page', type: 'page_content' } });
      notify(tab.id, `✓ Page envoyée à LaForge`);
    }
  }
  if (info.menuItemId === 'lf-open') {
    chrome.tabs.create({ url: chrome.runtime.getURL(
      `browser/linkgopher.html?tabId=${tab.id}&filtering=false&filteringDomains=false&onlyDomains=false`
    )});
  }
});

// ── Clic icone toolbar → ouvre Link Gopher ───────────────────────────────────
chrome.action.onClicked.addListener((tab) => {
  chrome.tabs.create({ url: chrome.runtime.getURL(
    `browser/linkgopher.html?tabId=${tab.id}&filtering=false&filteringDomains=false&onlyDomains=false`
  )});
});

// ── Messages depuis linkgopher.html ──────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  if (msg.action === 'extractLinks') {
    chrome.scripting.executeScript({
      target: { tabId: msg.tabId },
      func: () => {
        const links = [];
        for (let i = 0; i < document.links.length; i++)
          links.push(decodeURI(document.links[i].href));
        return links.length ? links : null;
      }
    }).then(r => sendResponse({ links: r?.[0]?.result ?? null }))
      .catch(e => sendResponse({ error: e.message }));
    return true;
  }

  if (msg.action === 'extractText') {
    chrome.scripting.executeScript({
      target: { tabId: msg.tabId },
      func: () => ({
        text:     document.body.innerText.substring(0, 12000),
        title:    document.title,
        url:      location.href,
        selected: window.getSelection()?.toString() || ''
      })
    }).then(r => sendResponse({ data: r?.[0]?.result ?? null }))
      .catch(e => sendResponse({ error: e.message }));
    return true;
  }

  if (msg.action === 'getTabs') {
    chrome.tabs.query({}, tabs => {
      sendResponse({ tabs: tabs
        .filter(t => t.url?.startsWith('http'))
        .map(t => ({ id:t.id, url:t.url, title:t.title||t.url, favIconUrl:t.favIconUrl||'' }))
      });
    });
    return true;
  }

  if (msg.action === 'getHistory') {
    // Firefox : text='' peut retourner rien → utiliser startTime + text
    const query = msg.query || '';
    const params = {
      text: query,
      maxResults: msg.maxResults || 300,
      startTime: Date.now() - (1000 * 60 * 60 * 24 * 90) // 90 jours
    };
    chrome.history.search(params, items => {
      const results = (items || [])
        .filter(i => i.url?.startsWith('http'))
        .sort((a,b) => b.lastVisitTime - a.lastVisitTime)
        .map(i => ({
          url: i.url,
          title: i.title || i.url,
          visitCount: i.visitCount,
          lastVisit: i.lastVisitTime
        }));
      sendResponse({ history: results, total: results.length });
    });
    return true;
  }
});


  // Qualification : ouvre chaque URL, extrait texte, ferme l'onglet
  if (msg.action === 'qualifyUrls') {
    (async () => {
      const results = [];
      for (const item of msg.items) {
        let tabId = null;
        try {
          // Ouvrir dans un onglet en arrière-plan
          const tab = await chrome.tabs.create({ url: item.url, active: false });
          tabId = tab.id;

          // Attendre que la page soit chargée (max 8s)
          await new Promise((resolve) => {
            const listener = (id, info) => {
              if (id === tabId && info.status === 'complete') {
                chrome.tabs.onUpdated.removeListener(listener);
                resolve();
              }
            };
            chrome.tabs.onUpdated.addListener(listener);
            setTimeout(resolve, 8000); // timeout
          });

          // Extraire texte + meta
          const extracted = await chrome.scripting.executeScript({
            target: { tabId },
            func: () => {
              const meta = (sel) => document.querySelector(sel)?.content || '';
              return {
                title:    document.title,
                text:     document.body.innerText.substring(0, 6000),
                lang:     document.documentElement.lang || '',
                desc:     meta('meta[name="description"]') || meta('meta[property="og:description"]'),
                keywords: meta('meta[name="keywords"]'),
                h1:       document.querySelector('h1')?.innerText || '',
                h2s:      [...document.querySelectorAll('h2')].slice(0,5).map(h=>h.innerText).join(' | ')
              };
            }
          });

          results.push({
            url:   item.url,
            title: item.title,
            ...( extracted?.[0]?.result || {} ),
            ok: true
          });

        } catch(e) {
          results.push({ url: item.url, title: item.title, error: e.message, ok: false });
        } finally {
          // Fermer l'onglet temporaire
          if (tabId) {
            try { await chrome.tabs.remove(tabId); } catch(e) {}
          }
        }

        // Petit délai entre chaque URL pour ne pas surcharger
        await new Promise(r => setTimeout(r, 500));
      }
      sendResponse({ results });
    })();
    return true; // async
  }

// ── Helpers ──────────────────────────────────────────────────────────────────
async function hubIngest(payload) {
  try {
    await fetch(`${HUB}/ingest/url`, {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(5000)
    });
  } catch(e) { console.warn('LaForge hub offline:', e.message); }
}

function notify(tabId, msg) {
  chrome.scripting.executeScript({
    target: { tabId },
    func: (m) => {
      const el = document.createElement('div');
      el.style.cssText = 'position:fixed;top:16px;right:16px;z-index:999999;background:#0d1117;color:#00d4ff;border:1px solid #00d4ff;padding:10px 16px;border-radius:6px;font-family:monospace;font-size:13px;box-shadow:0 4px 20px rgba(0,212,255,.3)';
      el.textContent = m;
      document.body.appendChild(el);
      setTimeout(() => el.remove(), 3000);
    },
    args: [msg]
  }).catch(() => {});
}
